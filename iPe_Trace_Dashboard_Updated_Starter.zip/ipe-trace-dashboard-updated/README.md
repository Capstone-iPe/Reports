# iPe Merchant Onboarding Copilot — Trace Dashboard Starter (Updated)

This is an instrumentable collector and dashboard starter aligned to the refreshed analysis repository snapshot (main commit `596c50940152e1fd625390679e0f23f749893c6e`, 18 Nov 2026).

## Status and boundary

- The analysis README says a per-turn trace schema exists, while exported traces and a working dashboard remain open.
- This package is **not deployed and is not connected to live copilot traffic**.
- The dashboard intentionally starts with an empty state. It never creates sample or synthetic traces.
- Metrics are computed only from events actually posted to the collector.
- This package does not imply that trace instrumentation, production persistence, access control, retention or redaction have already been completed in the copilot.

## Included

- `app.py`: FastAPI event collector, SQLite persistence, trace query APIs, metrics API and UI host.
- `trace_emitter.py`: best-effort Python emitter intended to be called from real copilot/ONB execution paths.
- `static/index.html`: responsive dashboard with trace list, detail timeline, latency percentiles and F01–F15 failure counts.
- `event.schema.json`: event contract.
- `render.yaml`: Render deployment template with persistent disk path.
- `.env.example`: configuration template.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export TRACE_DB_PATH=./traces.db
export TRACE_API_KEY=local-dev-secret
uvicorn app:APP --reload --port 8000
```

Open `http://localhost:8000`. Health check: `/health`.

## Event ingestion

`POST /v1/traces/events` accepts one event. When `TRACE_API_KEY` is configured, send it in the `X-API-Key` header.

Example (use only redacted test data):

```bash
curl -X POST http://localhost:8000/v1/traces/events \\
  -H 'Content-Type: application/json' \\
  -H 'X-API-Key: local-dev-secret' \\
  -d '{
    "trace_id":"trace-local-test-001",
    "span_id":"span-request-001",
    "event_type":"request",
    "stage":"request",
    "status":"ok",
    "duration_ms":12.4,
    "input_summary":"merchant asked for next required item"
  }'
```

The above is an API usage example only; it is not preloaded into the database or presented as measured project traffic.

## APIs

- `GET /health`
- `POST /v1/traces/events`
- `GET /v1/traces?limit=100&offset=0`
- `GET /v1/traces/{trace_id}`
- `GET /v1/metrics`

## Integration points

Instrument the actual execution paths and preserve parent-child correlation:

1. Request received (`request`).
2. Intent classification (`intent`).
3. ONB `next_step` call and response.
4. Policy retrieval when required (`retrieval`).
5. MCP tool call and result (`tool`).
6. ONB submit/rule result (`decision`).
7. Critic/guard result (`guard`).
8. Final response rendered (`response`).

Create one `trace_id` per user turn. Create a unique `span_id` per stage; set `parent_span_id` to the caller span. Include `application_id` and `turn_id` only if they are safe pseudonymous identifiers. Record model, prompt and corpus versions where useful. Use `failure_code` F01–F15 for a classified failure.

Example emitter usage:

```python
from trace_emitter import emit_event
emit_event(
    trace_id=trace_id,
    event_type="tool",
    stage="tool",
    tool_name="next_step",
    status="ok",
    duration_ms=18.2,
    input_summary="read current application state",
    output_summary="returned next required field",
)
```

Emitter calls are best-effort and have a short timeout. They should not block the business workflow or change the ONB result. In production, prefer a durable queue/outbox if trace delivery guarantees are required.

## Failure taxonomy

F01 Retrieval miss; F02 Retrieval contamination; F03 Intent classification error; F04 Next-step/state error; F05 Tool selection/argument error; F06 Tool execution/integration failure; F07 Persistence error; F08 Document verification error; F09 Decision-rule error; F10 Unsafe action/boundary breach; F11 Citation/grounding error; F12 Privacy/sensitive-data exposure; F13 Response rendering error; F14 Trace/observability gap; F15 Latency/capacity degradation.

## Security and operations checklist

- Never emit raw file bytes, full prompts, identity numbers, bank details, phone numbers, passwords, API keys or other secrets.
- Redact at the source, not only in the dashboard.
- Configure `TRACE_API_KEY`; rotate it and restrict network access.
- Use HTTPS, persistent disk, encrypted backups and access-controlled dashboard hosting.
- Set and document retention/deletion policy; SQLite is suitable as a starter, not a high-write distributed production store.
- Add rate limiting, payload-size limits, schema/version governance and alerting before production.
- Validate trace completeness, parent-child linkage and redaction with test traces before connecting live traffic.

## Important interpretation

An empty dashboard means no events have been ingested. It does **not** mean zero errors or perfect performance. Percentiles and failure counts are descriptive of the ingested sample only; they are not service-level objectives.
