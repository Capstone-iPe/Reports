"""Small, non-blocking trace emitter for the iPe copilot.
Call emit_event from actual execution paths. Never pass raw PII, file bytes,
credentials, complete prompts, bank details, identity numbers or phone numbers.
"""
import os, json, urllib.request, urllib.error, uuid
from datetime import datetime, timezone

TRACE_COLLECTOR_URL=os.getenv("TRACE_COLLECTOR_URL","").rstrip("/")
TRACE_API_KEY=os.getenv("TRACE_API_KEY","")

def emit_event(*, trace_id, event_type, name="event", stage=None, status="ok",
               duration_ms=None, span_id=None, parent_span_id=None,
               application_id=None, turn_id=None, tool_name=None,
               failure_code=None, error_type=None, model=None,
               prompt_version=None, corpus_version=None,
               policy_document_ids=None, input_summary=None,
               output_summary=None, metadata=None):
    """Send one redacted event. Returns True if accepted, False if disabled/fails."""
    if not TRACE_COLLECTOR_URL:
        return False
    payload={
      "trace_id":str(trace_id),"event_type":event_type,"name":name,
      "timestamp":datetime.now(timezone.utc).isoformat(),
      "span_id":span_id or str(uuid.uuid4()),"parent_span_id":parent_span_id,
      "application_id":application_id,"turn_id":turn_id,"stage":stage,
      "status":status,"duration_ms":duration_ms,"tool_name":tool_name,
      "failure_code":failure_code,"error_type":error_type,"model":model,
      "prompt_version":prompt_version,"corpus_version":corpus_version,
      "policy_document_ids":policy_document_ids or [],
      "input_summary":input_summary,"output_summary":output_summary,
      "metadata":metadata or {}
    }
    req=urllib.request.Request(
      TRACE_COLLECTOR_URL+"/v1/traces/events",
      data=json.dumps(payload).encode("utf-8"),
      headers={"Content-Type":"application/json","X-API-Key":TRACE_API_KEY},
      method="POST")
    try:
      with urllib.request.urlopen(req,timeout=1.5) as resp:
        return 200 <= resp.status < 300
    except (urllib.error.URLError, TimeoutError, ValueError):
      return False
