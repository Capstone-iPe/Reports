import os, json, sqlite3, time, uuid
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB_PATH = os.getenv("TRACE_DB_PATH", "/data/traces.db")
API_KEY = os.getenv("TRACE_API_KEY", "")
APP = FastAPI(title="iPe Copilot Trace Collector", version="2.0.0")
APP.mount("/static", StaticFiles(directory="static"), name="static")

FAILURES = {
 "F01":"Retrieval miss","F02":"Retrieval contamination","F03":"Intent classification error",
 "F04":"Next-step/state error","F05":"Tool selection/argument error","F06":"Tool execution/integration failure",
 "F07":"Persistence error","F08":"Document verification error","F09":"Decision-rule error",
 "F10":"Unsafe action/boundary breach","F11":"Citation/grounding error","F12":"Privacy/sensitive-data exposure",
 "F13":"Response rendering error","F14":"Trace/observability gap","F15":"Latency/capacity degradation"
}

class TraceEvent(BaseModel):
    trace_id: str = Field(min_length=1, max_length=128)
    event_type: str = Field(min_length=1, max_length=80)
    name: str = Field(default="event", max_length=160)
    timestamp: Optional[str] = None
    span_id: Optional[str] = Field(default=None, max_length=128)
    parent_span_id: Optional[str] = Field(default=None, max_length=128)
    application_id: Optional[str] = Field(default=None, max_length=128)
    turn_id: Optional[str] = Field(default=None, max_length=128)
    stage: Optional[str] = Field(default=None, max_length=80)
    status: str = Field(default="ok", max_length=32)
    duration_ms: Optional[float] = Field(default=None, ge=0)
    tool_name: Optional[str] = Field(default=None, max_length=80)
    failure_code: Optional[str] = Field(default=None, pattern=r"^F(0[1-9]|1[0-5])$")
    error_type: Optional[str] = Field(default=None, max_length=160)
    model: Optional[str] = Field(default=None, max_length=160)
    prompt_version: Optional[str] = Field(default=None, max_length=100)
    corpus_version: Optional[str] = Field(default=None, max_length=160)
    policy_document_ids: list[str] = Field(default_factory=list)
    input_summary: Optional[str] = Field(default=None, max_length=1000)
    output_summary: Optional[str] = Field(default=None, max_length=1000)
    metadata: dict[str, Any] = Field(default_factory=dict)

def connect():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT, trace_id TEXT NOT NULL, timestamp TEXT NOT NULL,
      event_type TEXT NOT NULL, stage TEXT, status TEXT NOT NULL, duration_ms REAL,
      failure_code TEXT, tool_name TEXT, payload TEXT NOT NULL)""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_events_trace ON events(trace_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_events_time ON events(timestamp)")
    c.commit()
    return c

def auth(x_api_key: Optional[str]):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")

def now_iso():
    return datetime.now(timezone.utc).isoformat()

@APP.on_event("startup")
def startup():
    c=connect(); c.close()

@APP.get("/")
def home():
    return FileResponse("static/index.html")

@APP.get("/health")
def health():
    return {"status":"ok","service":"ipe-trace-collector","version":"2.0.0"}

@APP.post("/v1/traces/events")
def ingest(event: TraceEvent, x_api_key: Optional[str]=Header(default=None)):
    auth(x_api_key)
    payload=event.model_dump()
    payload["timestamp"]=payload.get("timestamp") or now_iso()
    if payload.get("failure_code") and payload["status"] in ("ok","success"):
        payload["status"]="error"
    c=connect()
    cur=c.execute("""INSERT INTO events(trace_id,timestamp,event_type,stage,status,duration_ms,failure_code,tool_name,payload)
      VALUES(?,?,?,?,?,?,?,?,?)""",
      (payload["trace_id"],payload["timestamp"],payload["event_type"],payload.get("stage"),
       payload["status"],payload.get("duration_ms"),payload.get("failure_code"),payload.get("tool_name"),
       json.dumps(payload,ensure_ascii=False)))
    c.commit(); event_id=cur.lastrowid; c.close()
    return {"accepted":True,"event_id":event_id,"trace_id":payload["trace_id"]}

@APP.get("/v1/traces")
def traces(limit:int=Query(100,ge=1,le=500), offset:int=Query(0,ge=0), status:Optional[str]=None):
    c=connect()
    where=""; args=[]
    if status:
        where="WHERE status=?"; args.append(status)
    rows=c.execute(f"""SELECT trace_id, MIN(timestamp) AS started_at, MAX(timestamp) AS last_seen,
      COUNT(*) AS event_count, SUM(CASE WHEN status NOT IN ('ok','success','completed') THEN 1 ELSE 0 END) AS error_count,
      MAX(failure_code) AS failure_code FROM events {where} GROUP BY trace_id
      ORDER BY last_seen DESC LIMIT ? OFFSET ?""",args+[limit,offset]).fetchall()
    total=c.execute(f"SELECT COUNT(DISTINCT trace_id) FROM events {where}",args).fetchone()[0]
    c.close()
    return {"total":total,"items":[dict(r) for r in rows]}

@APP.get("/v1/traces/{trace_id}")
def trace_detail(trace_id:str):
    c=connect()
    rows=c.execute("SELECT id,payload FROM events WHERE trace_id=? ORDER BY timestamp ASC,id ASC",(trace_id,)).fetchall()
    c.close()
    if not rows: raise HTTPException(status_code=404,detail="Trace not found")
    return {"trace_id":trace_id,"events":[{"id":r["id"],**json.loads(r["payload"])} for r in rows]}

@APP.get("/v1/metrics")
def metrics():
    c=connect()
    total=c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    traces=c.execute("SELECT COUNT(DISTINCT trace_id) FROM events").fetchone()[0]
    failed=c.execute("SELECT COUNT(*) FROM events WHERE status NOT IN ('ok','success','completed')").fetchone()[0]
    durations=[r[0] for r in c.execute("SELECT duration_ms FROM events WHERE duration_ms IS NOT NULL").fetchall()]
    failures=c.execute("SELECT failure_code,COUNT(*) n FROM events WHERE failure_code IS NOT NULL GROUP BY failure_code ORDER BY failure_code").fetchall()
    stages=c.execute("SELECT COALESCE(stage,event_type) stage,COUNT(*) n,AVG(duration_ms) avg_ms FROM events GROUP BY COALESCE(stage,event_type) ORDER BY n DESC").fetchall()
    c.close()
    durations.sort()
    def pct(p):
        if not durations:return None
        return round(durations[min(len(durations)-1,int((len(durations)-1)*p))],2)
    return {"event_count":total,"trace_count":traces,"failed_event_count":failed,
      "error_rate":round(failed/total,4) if total else None,
      "latency_ms":{"p50":pct(.50),"p95":pct(.95),"p99":pct(.99)},
      "failure_counts":[{"code":r["failure_code"],"label":FAILURES.get(r["failure_code"],"Unknown"),"count":r["n"]} for r in failures],
      "stage_counts":[{"stage":r["stage"],"count":r["n"],"avg_duration_ms":round(r["avg_ms"],2) if r["avg_ms"] is not None else None} for r in stages],
      "data_available":total>0}
